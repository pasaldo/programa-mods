if not tweak_data then return end

tweak_data.gui.MAX_MASK_PAGES = 10
tweak_data.gui.MASK_ROWS_PER_PAGE = 4
tweak_data.gui.MASK_COLUMNS_PER_PAGE = 4
tweak_data.gui.MAX_WEAPON_PAGES = 10
tweak_data.gui.WEAPON_ROWS_PER_PAGE = 5
tweak_data.gui.WEAPON_COLUMNS_PER_PAGE = 5