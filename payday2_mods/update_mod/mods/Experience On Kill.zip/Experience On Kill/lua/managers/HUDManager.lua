local function CheckOptions(opt, default)
	if EXPOK._data[opt] then
		return EXPOK._data[opt]
	end

	return default
end

local function clone(func, ...)
    return func(...)
end

local function round(num, decimals)
	decimals = math.pow(10, decimals or 0)
	num = num * decimals

	if num >= 0 then
		 num = math.floor(num + 0.5)
	else
 		num = math.ceil(num - 0.5)
	end

	return num / decimals
end

local function custom_colors_con(value, special)
    local c = {
        pastel_pink = {255, 161, 220},
        purple = {240, 33, 255},
        aqua = {0, 255, 221},
        strawb = {251, 41, 65},
        orange = {255, 85, 0},
        red = {255, 0, 0},
        navy = {56, 63, 255},
        pink = {255, 0, 160},
        lilac = {223, 168, 255},
        black = {0, 0, 0},
        blue_violet = {169, 48, 255},
        white = {255, 255, 255},
        green = {0, 255, 0},
        yellow = {255, 255, 0}
    }

    local convert = {
        "pastel_pink",
        "purple",
        "aqua",
        "strawb",
        "orange",
        "red",
        "navy",
        "pink",
        "lilac",
        "black",
        "blue_violet",
        "white",
        "green",
        "yellow"
    }

    if not value then
		if not special then
    		return c.yellow[1]/255, c.yellow[2]/255, c.yellow[3]/255
		else
			return c.purple[1]/255, c.purple[2]/255, c.purple[3]/255
		end
    end

    return c[convert[value]][1]/255, c[convert[value]][2]/255, c[convert[value]][3]/255
end

local function packColorData(...)
	local r,g,b = custom_colors_con(...)
	return Color(r,g,b)
end

function HUDManager:_kill_exp(killstreak, was_special)
	local hud = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
	local child = hud.panel:child("exp_text____")
	local child2 = hud.panel:child("killstreak_text__")
	local child_bonus = hud.panel:child("exp_bonus_text____")
	local base_exp = round(managers.player:_exp_gain_manage(true),1)
	self._block_anim = (self._block_anim or false)
	self._previous_num = (self._previous_num or 0)
	self._exp_gained = (self._exp_gained or 0)
	was_special = was_special or managers.player:has_active_temporary_property("bonus_xp_special_killed")
	local killstreak_announce = { "DOUBLE", "TRIPLE", "QUADRA", "PENTA", "HEXA" }
	local function make_fine_text(text)
		local x, y, w, h = text:text_rect()

		text:set_size(w, h)
		text:set_position(math.round(text:x()), math.round(text:y()))
	end

	if was_special then
		self.played_anim_b = false
	end

	if child and alive(child) then
		hud.panel:remove(child)
	end

	if child2 and alive(child2) then
		hud.panel:remove(child2)
	end

	if was_special then
		if child_bonus and alive(child_bonus) then
			hud.panel:remove(child_bonus)
		end
	end

	if was_special then
		self._exp_bonus = hud.panel:text({
			name = "exp_bonus_text____",
			y = -100,
			rotation = 360,
			font_size = EXPOK._data.exp_font_size,
			vertical = "center",
			h = 40,
			visible = true,
			w = 40,
			align = "center",
			render_template = "OverlayVertexColorTextured",
			font = "fonts/font_medium_shadow_mf",
			text = "",
			color = packColorData(CheckOptions("specialkilled_color", 2), true)
		})
	end

	self._exp = hud.panel:text({
		name = "exp_text____",
		y = -100,
		rotation = 360,
		font_size = EXPOK._data.exp_font_size,
		vertical = "center",
		h = 40,
		visible = true,
		w = 40,
		align = "center",
		render_template = "OverlayVertexColorTextured",
		font = "fonts/font_medium_shadow_mf",
		text = "",
		color = packColorData(CheckOptions("exp_color", 14))
	})

	self._killstreak_ann = hud.panel:text({
		name = "killstreak_text__",
		y = -100,
		rotation = 360,
		font_size = EXPOK._data.kln_font_size,
		vertical = "center",
		h = 40,
		visible = true,
		w = 40,
		align = "center",
		render_template = "OverlayVertexColorTextured",
		font = "fonts/font_medium_shadow_mf",
		text = "",
		color = packColorData(CheckOptions("exp_color", 14)),
		alpha = 0.9
	})

	local bonus_xp = self._exp_bonus
	local text = self._exp
	local kln = self._killstreak_ann
	local shortcut_choice = { " EXP", " »XP" }
	local shrt = shortcut_choice[CheckOptions("shortcut_choice_exp", 2)]

	self._exp_gained = self._exp_gained + base_exp
	local exp_text = "+" .. tostring(self._exp_gained) .. shrt
	text:set_text(exp_text)

	if killstreak >= 2 then
		for i, ann in pairs(killstreak_announce) do
			if killstreak == i + 1 then
				kln:set_text(ann .. " KILL")
				break
			end
		end
	end

	if killstreak > 6 then
		kln:set_text("BLOODTHIRSTY!")
	end

	--make_fine_text(text)
	make_fine_text(kln)

	local function init_exp(o, dir)
		local mt = 0.15
		local t = mt

		while t > 0 do
			local dt = coroutine.yield()
			t = math.clamp(t - dt, 0, 0.9)
			local speed = dt * 500

			o:move(dir * speed, (1 - math.abs(dir)) * -speed)
		end

		text:remove(o)
		text:hide()
	end

	text:animate(init_exp, -0)

	local scale_x = EXPOK._data.exp_font_size / 20
	text:set_visible(true)
	text:set_center(hud.panel:w() / 2, hud.panel:h() / 2)

	if CheckOptions("exp_adjust_x", 60) == 60 then
		text:set_x(text:x() + (60 * scale_x))
	else
		text:set_x(text:x() + CheckOptions("exp_adjust_x", 60))
	end

	text:set_y(text:y() + CheckOptions("exp_adjust_y", 40))

	if was_special then
		self._bonus_xp_earned = (self._bonus_xp_earned or 0) + ((base_exp * 1.2) - base_exp)
		bonus_xp:set_text("+" .. tostring(round(self._bonus_xp_earned, 1)) .. shrt)
		bonus_xp:set_visible(true)
		bonus_xp:set_x(text:x())
		bonus_xp:set_y(text:y() - 15)
	end

	local function block_anim(set)
		if set == true then
			if self._previous_num < killstreak then
				self._previous_num = killstreak
				self._block_anim = set

				return
			end
		end
		self._block_anim = set
	end

	local function init_bonus(o, dir)
		local mt = 0.15
		local t = mt

		while t > 0 do
			local dt = coroutine.yield()
			t = math.clamp(t - dt, 0, 0.9)
			local speed = dt * 500

			o:move(dir * speed, (1 - math.abs(dir)) * -speed)
			block_anim(true)
		end

		bonus_xp:remove(o)
		bonus_xp:hide()
	end

	if was_special then
		bonus_xp:animate(init_bonus, -0)
	end

	local function init_kln(o, dir)
		local mt = 0.25
		local t = mt

		while t > 0 do
			local dt = coroutine.yield()
			t = math.clamp(t - dt, 0, 0.9)
			local speed = dt * 500

			o:move(dir * speed, (1 - math.abs(dir)) * -speed)
			block_anim(true)
		end

		kln:remove(o)
		kln:hide()
	end

	if not self._block_anim or self._previous_num <= 6 then
		kln:animate(init_kln, -0)
	end

	kln:set_visible(EXPOK._data.show_announcer)
	kln:set_center(hud.panel:w() / 2, hud.panel:h() / 2)
	local scale_x_kln = EXPOK._data.kln_font_size / 20

	if CheckOptions("kln_adjust_x", 60) == 60 then
		kln:set_x(text:x() + (60 * scale_x_kln))
	else
		kln:set_x(text:x() + CheckOptions("kln_adjust_x", 60))
	end

	kln:set_y(text:y() + CheckOptions("kln_adjust_y", 70))

	if self._previous_num > 6 then
		kln:set_y(text:y() - CheckOptions("kln_adjust_y", 70) + 15)
	end

	local function func2(o, dir)
		local mt = 1
		local t = mt

		while t > 0 do
			local dt = coroutine.yield()
			t = math.clamp(t - dt, 0, 1)
			local speed = dt * 20

			o:move(dir * speed, (1 - math.abs(dir)) * -speed)
			text:set_alpha(t)
		end

		text:remove(o)
		text:hide()
	end

	local function func_bonus(o, dir)
		local mt = 1
		local t = mt

		while t > 0 do
			local dt = coroutine.yield()
			t = math.clamp(t - dt, 0, 1)
			local speed = dt * 20

			o:move(dir * speed, (1 - math.abs(dir)) * -speed)
			bonus_xp:set_alpha(t)
		end

		bonus_xp:remove(o)
		bonus_xp:hide()
	end

	local function func(o, dir)
		local mt = 4
		local t = mt

		while t > 0 do
			local dt = coroutine.yield()
			t = math.clamp(t - dt, 0, 0.9)
			local speed = dt * 20

			o:move(dir * speed, (1 - math.abs(dir)) * -speed)
			kln:set_alpha(t)
		end

		kln:remove(o)
		kln:hide()
	end

	DelayedCalls:Add("text__anim", EXPOK._data.exp_text_duration, function()
		text:animate(func2, CheckOptions("exp_fade_out_style", 1) - 1)

		if bonus_xp and not self.played_anim_b then
			bonus_xp:animate(func_bonus, CheckOptions("exp_fade_out_style", 1) - 1)
			self:BONUS_PLAYED_ANIM(true)
		end

		if not managers.player:has_active_temporary_property("bonus_xp_special_killed") then
			self._bonus_xp_earned = nil
		end

		self._exp_gained = nil
		managers.player:_killstreak_manage(true)
	end)

	DelayedCalls:Add("kln__anim", EXPOK._data.kln_duration, function()
		kln:animate(func, 1)
		block_anim(false)
		self._bonus_xp_earned = nil
		self._previous_num = nil
	end)
end

function HUDManager:BONUS_PLAYED_ANIM(chk)
	self.played_anim_b = chk
end

function HUDManager:_force_remove_bonus_xp()
	local hud = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
	local child_bonus = hud.panel:child("exp_bonus_text____")
	if self._exp_bonus then
		local bonus_xp = self._exp_bonus
		local function func_bonus(o, dir)
			local mt = 1
			local t = mt

			while t > 0 do
				local dt = coroutine.yield()
				t = math.clamp(t - dt, 0, 1)
				local speed = dt * 20

				o:move(dir * speed, (1 - math.abs(dir)) * -speed)
				bonus_xp:set_alpha(t)
			end

			bonus_xp:remove(o)
			bonus_xp:hide()
		end

		if not child_bonus or not alive(child_bonus) then
			return
		end

		if self.played_anim_b then
			self._bonus_xp_earned = nil
			return
		end

		bonus_xp:animate(func_bonus, CheckOptions("exp_fade_out_style", 1) - 1)
		self._bonus_xp_earned = nil
		self:BONUS_PLAYED_ANIM(true)
	end
end