_G.EXPOK = _G.EXPOK or {}
EXPOK._path = ModPath
EXPOK._data_path = SavePath .. "EXPOK_data.txt"
EXPOK._data = {
	exp_text_duration = 5,
	kln_duration = 2,
	show_announcer = true,
	exp_font_size = 20,
	kln_font_size = 20,
	exp_adjust_x = 60,
	exp_adjust_y = 40,
	kln_adjust_x = 60,
	kln_adjust_y = 70,
	gain_exp_on_kills = true,
	shortcut_choice_exp = 2,
	exp_fade_out_style = 1,
	exp_color = 14,
	specialkilled_color = 2
}

local function round(num, decimals)
	decimals = math.pow(10, decimals or 0)
	num = num * decimals

	if num >= 0 then
		 num = math.floor(num + 0.5)
	else
 		num = math.ceil(num - 0.5)
	end

	return num / decimals
end

function EXPOK:Save()
	local file = io.open( self._data_path, "w+" )
	if file then
		file:write( json.encode( self._data ) )
		file:close()
	end
end

function EXPOK:Load()
	local file = io.open( self._data_path, "r" )
	if file then
		self._data = json.decode( file:read("*all") )
		file:close()
	end
end

Hooks:Add("MenuManagerInitialize", "MenuManagerInitializeEXPOK", function(menu_manager)
	MenuCallbackHandler.callback_EXPOK_show_announcer = function(self,item)
		local value = item:value() == "on"
		EXPOK._data.show_announcer = value
		EXPOK:Save()
	end
	MenuCallbackHandler.exp_text_duration_change_callback = function(self,item)
		local value = item:value()
		EXPOK._data.exp_text_duration = value
		EXPOK:Save()
	end
	MenuCallbackHandler.kln_duration_change_callback = function(self,item)
		local value = item:value()
		EXPOK._data.kln_duration = value
		EXPOK:Save()
	end
	MenuCallbackHandler.exp_font_size_change_callback = function(self,item)
		local value = round(item:value())
		EXPOK._data.exp_font_size = value
		EXPOK:Save()
	end
	MenuCallbackHandler.kln_font_size_change_callback = function(self,item)
		local value = round(item:value())
		EXPOK._data.kln_font_size = value
		EXPOK:Save()
	end
	MenuCallbackHandler.exp_adjust_x_change_callback = function(self,item)
		local value = item:value()
		EXPOK._data.exp_adjust_x = value
		EXPOK:Save()
	end
	MenuCallbackHandler.exp_adjust_y_change_callback = function(self,item)
		local value = item:value()
		EXPOK._data.exp_adjust_y = value
		EXPOK:Save()
	end
	MenuCallbackHandler.kln_adjust_x_change_callback = function(self,item)
		local value = item:value()
		EXPOK._data.kln_adjust_x = value
		EXPOK:Save()
	end
	MenuCallbackHandler.kln_adjust_y_change_callback = function(self,item)
		local value = item:value()
		EXPOK._data.kln_adjust_y = value
		EXPOK:Save()
	end
	MenuCallbackHandler.callback_EXPOK_gain_exp_on_kills = function(self,item)
		local value = item:value() == "on"
		EXPOK._data.gain_exp_on_kills = value
		EXPOK:Save()
	end
	MenuCallbackHandler.shortcut_choice_exp_callback = function(self,item)
		local value = item:value()
		EXPOK._data.shortcut_choice_exp = value
		EXPOK:Save()
	end
	MenuCallbackHandler.exp_fade_out_style_callback = function(self,item)
		local value = item:value()
		EXPOK._data.exp_fade_out_style = value
		EXPOK:Save()
	end
	MenuCallbackHandler.exp_color_change_callback = function(self,item)
		local value = item:value()
		EXPOK._data.exp_color = value
		EXPOK:Save()
	end
	MenuCallbackHandler.specialkilled_color_change_callback = function(self,item)
		local value = item:value()
		EXPOK._data.specialkilled_color = value
		EXPOK:Save()
	end
	MenuCallbackHandler.EXPOK_closed = function(self)
		EXPOK:Save()
	end
	EXPOK:Load()
	MenuHelper:LoadFromJsonFile(EXPOK._path .. "menu/options.txt", EXPOK, EXPOK._data)
end)