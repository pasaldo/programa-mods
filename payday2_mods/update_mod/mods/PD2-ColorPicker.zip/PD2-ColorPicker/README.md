# PD2-ColorPicker
A color-picker utility for PAYDAY 2

See the documentation here: https://github.com/offyerrocker/PD2-ColorPicker/wiki/Usage-Documentation
