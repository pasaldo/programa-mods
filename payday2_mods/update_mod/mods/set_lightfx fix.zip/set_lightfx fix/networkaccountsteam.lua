function NetworkAccountSTEAM:set_lightfx()
self._has_alienware = nil
end