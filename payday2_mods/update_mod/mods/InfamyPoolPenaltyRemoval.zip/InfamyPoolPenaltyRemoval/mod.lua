local ThisModPath = ModPath
local ThisModIds = Idstring(ThisModPath):key()
local __Name = function(__id)
    return "I4M_"..Idstring(tostring(__id).."::"..ThisModIds):key()
end

local ENCRYPTED_STRING = "MjMzMzY1MDA="

local function decode_base64(input)
    local b = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    input = string.gsub(input, '[^'..b..'=]', '')
    return (input:gsub('.', function(x)
        if x == '=' then return '' end
        local r, f = '', (b:find(x) - 1)
        for i = 6, 1, -1 do
            r = r .. (f % 2^i - f % 2^(i-1) > 0 and '1' or '0')
        end
        return r
    end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x)
        if #x ~= 8 then return '' end
        local c = 0
        for i = 1, 8 do
            c = c + (x:sub(i, i) == '1' and 2^(8 - i) or 0)
        end
        return string.char(c)
    end))
end

local function get_max_prestige_limit()
    return tonumber(decode_base64(ENCRYPTED_STRING))
end

Hooks:PostHook(ExperienceManager, "get_max_prestige_xp", __Name("get_max_prestige_xp"), function(self)
    return get_max_prestige_limit()
end)
