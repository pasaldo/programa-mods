function NPCRaycastWeaponBase:add_damage_multiplier(damage_multiplier)
    local base_damage_mul = 0.65
    self._damage = self._damage * base_damage_mul

	self._damage = self._damage * damage_multiplier
end