local orig_interact_start, is_client, equipment_to_spawn = ObjectInteractionManager.end_action_interact, Network:is_client(), {
	"units/payday2/equipment/gen_equipment_ammobag/gen_equipment_ammobag",
	"units/pd2_dlc_old_hoxton/equipment/gen_equipment_first_aid_kit/gen_equipment_first_aid_kit"
}
function ObjectInteractionManager:end_action_interact(player, ...)
	local result = orig_interact_start(self, player, ...)
	local unit = self._active_unit

	if not is_client and player and player == managers.player:player_unit() and not self._active_object_locked_data and math.random() < 0.5 and alive(unit) and unit.interaction and unit:interaction().tweak_data == "hostage_trade" then
		safe_spawn_unit(Idstring(equipment_to_spawn[math.random(1, #equipment_to_spawn)]), unit:position(), Rotation(player:camera():rotation():yaw(), 0, 0))
	end

	return result
end