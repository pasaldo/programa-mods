if Network:is_client() then
	return
end

if RequiredScript == "lib/units/beings/player/states/playerstandard" then
	local orig_get_intimidation_action = PlayerStandard._get_intimidation_action
	function PlayerStandard:_get_intimidation_action(prime_target, ...)
		if not managers.groupai:state():whisper_mode() and prime_target and alive(prime_target.unit) and prime_target.unit.character_damage and prime_target.unit:character_damage().is_civilian and prime_target.unit:character_damage().is_civilian(prime_target.unit:base()._tweak_table) then
			for _, u_data in pairs(managers.enemy:all_civilians()) do
				u_data.unit:brain():set_objective({
					is_default = true,
					type = "free"
				})
				u_data.unit:brain():action_request({
					variant = "stand",
					body_part = 1,
					type = "free"
				})
				u_data.unit:brain():on_intimidated(10000, managers.player:player_unit())
			end
		end
		
		return orig_get_intimidation_action(self, prime_target, ...)
	end
end