if Network:is_client() then
	return
end

local orig_update, temp_count, first_delay = GroupAIStateBase.update, 0, false
function GroupAIStateBase:update(...)
    local hostage_count = self._enemy_weapons_hot and self._hostage_headcount - math.min(self._hostage_headcount, self._police_hostage_headcount) or 0

    if hostage_count and self._assault_number == 0 then
        local hostage_delay = 5

        if hostage_count < temp_count then
            local function sub_delay()
                temp_count = hostage_count

                if math.fmod(hostage_count, 5) ~= 0 then
                    hostage_delay = hostage_delay + 20
                end
            end

            if self._task_data.assault and self._task_data.assault.phase_end_t then
                sub_delay()
                
                self._task_data.assault.phase_end_t = self._task_data.assault.phase_end_t - math.min(self._task_data.assault.phase_end_t, hostage_delay)
            elseif self._point_of_no_return_timer then
                sub_delay()

                self._point_of_no_return_timer = self._point_of_no_return_timer - math.min(self._point_of_no_return_timer, hostage_delay)
            end
        elseif hostage_count > temp_count then
            local function add_delay()
                temp_count = hostage_count

                if not first_delay then
                    first_delay = true
                    hostage_delay = hostage_count * 5
                end

                if math.fmod(hostage_count, 5) == 0 then
                    hostage_delay = hostage_delay + 20
                end
            end

            if self._task_data.assault and self._task_data.assault.phase_end_t then
                add_delay()

                self._task_data.assault.phase_end_t = self._task_data.assault.phase_end_t + hostage_delay
                self._task_data.assault.phase = "fade"
            elseif self._point_of_no_return_timer then
                add_delay()

                self._point_of_no_return_timer = self._point_of_no_return_timer + hostage_delay
            end
        end
    end

    return orig_update(self, ...)
end
