function ZipLine:_update_total_time()
	if Global.game_settings.level_id == "kosugi" or Global.game_settings.level_id == "kosugi_prof" then
		self:set_total_time((self:start_pos() - self:end_pos()):length() / 2000)
	elseif Global.game_settings.level_id == "branchbank" or Global.game_settings.level_id == "firestarter_3" then
		self:set_total_time((self:start_pos() - self:end_pos()):length() / 1200)
	elseif Global.game_settings.level_id == "rat" or Global.game_settings.level_id == "alex_1" then
		self:set_total_time((self:start_pos() - self:end_pos()):length() / 1200)
	elseif Global.game_settings.level_id == "alex_3" then
		self:set_total_time((self:start_pos() - self:end_pos()):length() / 1200)
	elseif Global.game_settings.level_id == "big" then
		self:set_total_time((self:start_pos() - self:end_pos()):length() / 1200)
	elseif Global.game_settings.level_id == "arena" then
		self:set_total_time((self:start_pos() - self:end_pos()):length() / 1000)
	elseif Global.game_settings.level_id == "arm_for" then
		self:set_total_time((self:start_pos() - self:end_pos()):length() / 1337)
	elseif Global.game_settings.level_id == "pines" then
		self:set_total_time((self:start_pos() - self:end_pos()):length() / 1337)
	elseif Global.game_settings.level_id == "framing_frame_3" then
		self:set_total_time((self:start_pos() - self:end_pos()):length() / 1500)
	elseif Global.game_settings.level_id == "crojob2" then
		self:set_total_time((self:start_pos() - self:end_pos()):length() / 1337)
	elseif Global.game_settings.level_id == "crojob2" or Global.game_settings.level_id == "crojob3" then
		self:set_total_time((self:start_pos() - self:end_pos()):length() / 1337)
	else
		self:set_total_time((self:start_pos() - self:end_pos()):length() / 800) --optional
	end
end