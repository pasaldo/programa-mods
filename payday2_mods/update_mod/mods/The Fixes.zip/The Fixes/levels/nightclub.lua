TheFixesPreventer = TheFixesPreventer or {}
if TheFixesPreventer.heist_nightclub_fall then
	return
end


safe_spawn_unit(Idstring('units/world/props/mansion/man_cover_int_shipping_box_pallet/man_cover_int_shipping_box_pallet'), Vector3(1243, -9444, 24), Rotation(0,0,0))
