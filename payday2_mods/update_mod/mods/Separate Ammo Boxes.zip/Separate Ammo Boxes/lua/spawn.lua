function GamePlayCentralManager:spawn_pickup(params)
	if not tweak_data.pickups[params.name] then
		Application:error("No pickup definition for " .. tostring(params.name))
		return
	end
	local unit_name = tweak_data.pickups[params.name].unit
	return World:spawn_unit(unit_name, params.position, params.rotation)
end