_G.separate_ammo_boxes = {}

Hooks:PostHook(AmmoClip, 'init', 'SeparateAmmoBoxes_ammo',
function(self, unit)
	if Network:is_server() then
		_G.separate_ammo_boxes[unit:id()] = self
	else
		if _G.separate_ammo_boxes[unit:id()] then
			unit:set_visible(false)
			self._picked_up = true
			_G.separate_ammo_boxes[unit:id()] = nil
		end
	end
end)