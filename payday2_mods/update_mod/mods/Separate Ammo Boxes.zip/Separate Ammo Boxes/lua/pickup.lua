local mvec_1 = Vector3()
local mvec_2 = Vector3()

Hooks:PreHook(CopDamage, 'die', 'SeparateAmmoBoxes_pickup',
function(self, attack_data)
	if Network:is_server() and Global.game_settings.permission == 'friends_only' and managers.network:session() then
		self.on_death_attacker_unit = attack_data.attacker_unit
	end
end)

function CopDamage:drop_pickup(extra)
	if self._pickup then
		local tracker = self._unit:movement():nav_tracker()
		local position = tracker:lost() and tracker:field_position() or tracker:position()
		local rotation = self._unit:rotation()
		mvector3.set(mvec_1, position)
		if extra then
			mvector3.set_static(mvec_2, math.random(20, 50) * (math.random(1, 2) * 2 - 3), math.random(20, 50) * (math.random(1, 2) * 2 - 3), 0)
			mvector3.add(mvec_1, mvec_2)
		end
		local level_data = tweak_data.levels[managers.job:current_level_id()]
		if level_data and level_data.drop_pickups_to_ground then
			mvector3.set(mvec_2, math.UP)
			mvector3.multiply(mvec_2, -200)
			mvector3.add(mvec_2, mvec_1)
			local ray = self._unit:raycast("ray", mvec_1, mvec_2, "slot_mask", managers.slot:get_mask("bullet_impact_targets"))
			if ray then
				mvector3.set(mvec_1, ray.hit_position)
			end
		end
		local ammo_box_unit = managers.game_play_central:spawn_pickup({
			name = self._pickup,
			position = mvec_1,
			rotation = rotation
		})
		if self.on_death_attacker_unit then
			local attacker_unit = self.on_death_attacker_unit
			local separate_ammo_box = _G.separate_ammo_boxes[ammo_box_unit:id()]
			local player_kill = false
			for _, peer in pairs(managers.network:session():all_peers()) do
				if attacker_unit == peer:unit() then player_kill = true end
			end
			if player_kill then
				if attacker_unit ~= managers.network:session():local_peer():unit() then
					ammo_box_unit:set_visible(false)
					if separate_ammo_box then
						separate_ammo_box._picked_up = true
						_G.separate_ammo_boxes[ammo_box_unit:id()] = nil
					end
				end
				LuaNetworking:SendToPeers('SeparateAmmoBoxes_sync_pickup_ownership', tostring(attacker_unit:id()) .. '#' .. tostring(ammo_box_unit:id()))
			end
			if attacker_unit:base().sentry_gun then
				if attacker_unit:base()._owner_id ~= managers.network:session():local_peer():id() then
					ammo_box_unit:set_visible(false)
					if separate_ammo_box then
						separate_ammo_box._picked_up = true
						_G.separate_ammo_boxes[ammo_box_unit:id()] = nil
					end
				end
				LuaNetworking:SendToPeers('SeparateAmmoBoxes_sync_pickup_ownership', tostring(managers.network:session():peer(attacker_unit:base()._owner_id):unit():id()) .. '#' .. tostring(ammo_box_unit:id()))
			end
		end
	end
end

Hooks:AddHook('NetworkReceivedData', 'SeparateAmmoBoxes_receive_pickup_ownership',
function(sender, id, stream)
	if Network:is_client() and id == 'SeparateAmmoBoxes_sync_pickup_ownership' then
		local data = string.split(stream, '#')
		local attacker_id = tonumber(data[1])
		local ammo_id = tonumber(data[2])
		if managers.player:local_player() and attacker_id ~= managers.player:local_player():id() then
			_G.separate_ammo_boxes[ammo_id] = true
		end
	end
end)