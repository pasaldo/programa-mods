_G.Menucustom_pages = _G.Menucustom_pages or {}
Menucustom_pages._path = ModPath
Menucustom_pages._data_path = ModPath .. "/save/Menucustom_pages_options.txt"
Menucustom_pages._data = {}
function Menucustom_pages:Save()
	local file = io.open( self._data_path, "w+" )
	if file then
		file:write( json.encode( self._data ) )
		file:close()
	end
end
function Menucustom_pages:Load()
	local file = io.open( self._data_path, "r" )
	if file then
		self._data = json.decode( file:read("*all") )
		file:close()
		if self._data.custom_pages_page_1_val  == nil  then self._data.custom_pages_page_1_val 	= 1 end
		if self._data.custom_pages_page_2_val  == nil  then self._data.custom_pages_page_2_val 	= 2 end
		if self._data.custom_pages_page_3_val  == nil  then self._data.custom_pages_page_3_val 	= 3 end
		if self._data.custom_pages_page_4_val  == nil  then self._data.custom_pages_page_4_val 	= 4 end
		if self._data.custom_pages_page_5_val  == nil  then self._data.custom_pages_page_5_val 	= 5 end
		if self._data.custom_pages_page_6_val  == nil  then self._data.custom_pages_page_6_val 	= 6 end
		if self._data.custom_pages_page_7_val  == nil  then self._data.custom_pages_page_7_val 	= 7 end
		if self._data.custom_pages_page_8_val  == nil  then self._data.custom_pages_page_8_val 	= 8 end
		if self._data.custom_pages_page_9_val  == nil  then self._data.custom_pages_page_9_val 	= 9 end
		if self._data.custom_pages_page_10_val == nil  then self._data.custom_pages_page_10_val = 10 end
		if self._data.custom_pages_page_sec_1_val  == nil  then self._data.custom_pages_page_sec_1_val 	= 1 end
		if self._data.custom_pages_page_sec_2_val  == nil  then self._data.custom_pages_page_sec_2_val 	= 2 end
		if self._data.custom_pages_page_sec_3_val  == nil  then self._data.custom_pages_page_sec_3_val 	= 3 end
		if self._data.custom_pages_page_sec_4_val  == nil  then self._data.custom_pages_page_sec_4_val 	= 4 end
		if self._data.custom_pages_page_sec_5_val  == nil  then self._data.custom_pages_page_sec_5_val 	= 5 end
		if self._data.custom_pages_page_sec_6_val  == nil  then self._data.custom_pages_page_sec_6_val 	= 6 end
		if self._data.custom_pages_page_sec_7_val  == nil  then self._data.custom_pages_page_sec_7_val 	= 7 end
		if self._data.custom_pages_page_sec_8_val  == nil  then self._data.custom_pages_page_sec_8_val 	= 8 end
		if self._data.custom_pages_page_sec_9_val  == nil  then self._data.custom_pages_page_sec_9_val 	= 9 end
		if self._data.custom_pages_page_sec_10_val == nil  then self._data.custom_pages_page_sec_10_val = 10 end
		Menucustom_pages:Save()
	end
end
Hooks:Add("MenuManagerInitialize", "Menucustom_pages_MenuManagerInitialize", function(menu_manager)
	MenuCallbackHandler.Menucustom_pages_save = function(self, item)
		Menucustom_pages:Save()
	end	
	MenuCallbackHandler.custom_pages_page_1_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_1_val = item:value()
	end
	MenuCallbackHandler.custom_pages_page_2_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_2_val = item:value()
	end
	MenuCallbackHandler.custom_pages_page_3_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_3_val = item:value()
	end
	MenuCallbackHandler.custom_pages_page_4_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_4_val = item:value()
	end
	MenuCallbackHandler.custom_pages_page_5_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_5_val = item:value()
	end
	MenuCallbackHandler.custom_pages_page_6_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_6_val = item:value()
	end
	MenuCallbackHandler.custom_pages_page_7_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_7_val = item:value()
	end
	MenuCallbackHandler.custom_pages_page_8_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_8_val = item:value()
	end
	MenuCallbackHandler.custom_pages_page_9_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_9_val = item:value()
	end
	MenuCallbackHandler.custom_pages_page_10_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_10_val = item:value()
	end
	MenuCallbackHandler.custom_pages_page_sec_1_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_sec_1_val = item:value()
	end
	MenuCallbackHandler.custom_pages_page_sec_2_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_sec_2_val = item:value()
	end
	MenuCallbackHandler.custom_pages_page_sec_3_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_sec_3_val = item:value()
	end
	MenuCallbackHandler.custom_pages_page_sec_4_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_sec_4_val = item:value()
	end
	MenuCallbackHandler.custom_pages_page_sec_5_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_sec_5_val = item:value()
	end
	MenuCallbackHandler.custom_pages_page_sec_6_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_sec_6_val = item:value()
	end
	MenuCallbackHandler.custom_pages_page_sec_7_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_sec_7_val = item:value()
	end
	MenuCallbackHandler.custom_pages_page_sec_8_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_sec_8_val = item:value()
	end
	MenuCallbackHandler.custom_pages_page_sec_9_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_sec_9_val = item:value()
	end
	MenuCallbackHandler.custom_pages_page_sec_10_func = function(self, item)
		Menucustom_pages._data.custom_pages_page_sec_10_val = item:value()
	end
	Menucustom_pages:Load()
	MenuHelper:LoadFromJsonFile(Menucustom_pages._path .. "/options.txt", Menucustom_pages, Menucustom_pages._data)
end )