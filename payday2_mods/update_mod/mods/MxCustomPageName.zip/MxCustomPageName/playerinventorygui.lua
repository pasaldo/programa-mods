PlayerInventoryGui.open_weapon_category_menu = function(self, category)
	if not managers.blackmarket:get_crafted_category(category) then
		local crafted_category = {}
	end
	crafted_category = {}
	log('mxgui')
	local new_node_data = {category = category}
	local rows = tweak_data.gui.WEAPON_ROWS_PER_PAGE or 3
	local columns = tweak_data.gui.WEAPON_COLUMNS_PER_PAGE or 3
	local max_pages = tweak_data.gui.MAX_WEAPON_PAGES or 8
	local items_per_page = rows * columns
	local item_data, selected_tab = nil, nil
	for page = 1, max_pages do
		local index = 1
		local start_i = 1 + items_per_page * (page - 1)
		item_data = {}
		for i = start_i, items_per_page * page do
			item_data[index] = i
			index = index + 1
			if crafted_category[i] and crafted_category[i].equipped then
				selected_tab = page
			end
		end
		--local name_id = managers.localization:to_upper_text("bm_menu_page", {page = tostring(page)})
		--log('category'..tostring(category))
		local name_id = managers.localization:to_upper_text('bm_custom_page_'..tostring(category)..'_'..tostring(page))
		table.insert(new_node_data, {name = category, category = category, prev_node_data = false, start_i = start_i, allow_preview = true, name_localized = name_id, on_create_func_name = "populate_weapon_category_new", on_create_data = item_data, identifier = BlackMarketGui.identifiers.weapon, 
override_slots = {columns, rows}})
	end
	new_node_data.can_move_over_tabs = true
	new_node_data.selected_tab = selected_tab
	new_node_data.scroll_tab_anywhere = true
	new_node_data.topic_id = "bm_menu_" .. category
	new_node_data.topic_params = {weapon_category = managers.localization:text("bm_menu_weapons")}
	managers.menu:open_node("blackmarket_node", {new_node_data})
end