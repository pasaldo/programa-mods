local original_text = LocalizationManager.text

function LocalizationManager:text(string_id, ...)
local custom_text = {
    "Assault Rifles",
    "Akimbos",
    "Shotguns",
    "LMGs",
    "Specials",
    "Snipers",
    "Bows",
    "Grenade launchers",
    "Utility",
    "3.Edit me in bm_pages.lua"
}

local custom_text_secondary = {
    "Pistols",
    "SMGs",
    "Shotguns",
    "Specials",
    "Utility",
    "Grenade launchers",
    "Crossbows",
    "1.Edit me in bm_pages.lua",
    "2.Edit me in bm_pages.lua",
    "3.Edit me in bm_pages.lua"
}
--log(custom_text[Menucustom_pages._data.custom_pages_page_1_val])
return
   string_id == "bm_custom_page_primaries_1"  and tostring(custom_text[Menucustom_pages._data.custom_pages_page_1_val]) 		--Page 1
or string_id == "bm_custom_page_primaries_2"  and tostring(custom_text[Menucustom_pages._data.custom_pages_page_2_val])  		--Page 2
or string_id == "bm_custom_page_primaries_3"  and tostring(custom_text[Menucustom_pages._data.custom_pages_page_3_val])  		--Page 3
or string_id == "bm_custom_page_primaries_4"  and tostring(custom_text[Menucustom_pages._data.custom_pages_page_4_val])  		--Page 4
or string_id == "bm_custom_page_primaries_5"  and tostring(custom_text[Menucustom_pages._data.custom_pages_page_5_val])  		--Page 5
or string_id == "bm_custom_page_primaries_6"  and tostring(custom_text[Menucustom_pages._data.custom_pages_page_6_val]) 		--Page 6
or string_id == "bm_custom_page_primaries_7"  and tostring(custom_text[Menucustom_pages._data.custom_pages_page_7_val])  		--Page 7
or string_id == "bm_custom_page_primaries_8"  and tostring(custom_text[Menucustom_pages._data.custom_pages_page_8_val])  		--Page 8
or string_id == "bm_custom_page_primaries_9"  and tostring(custom_text[Menucustom_pages._data.custom_pages_page_9_val])  		--Page 9
or string_id == "bm_custom_page_primaries_10" and tostring(custom_text[Menucustom_pages._data.custom_pages_page_10_val]) 		--Page 10

or string_id == "bm_custom_page_secondaries_1"  and tostring(custom_text_secondary[Menucustom_pages._data.custom_pages_page_sec_1_val]) 		--Page 1
or string_id == "bm_custom_page_secondaries_2"  and tostring(custom_text_secondary[Menucustom_pages._data.custom_pages_page_sec_2_val])  		--Page 2
or string_id == "bm_custom_page_secondaries_3"  and tostring(custom_text_secondary[Menucustom_pages._data.custom_pages_page_sec_3_val])  		--Page 3
or string_id == "bm_custom_page_secondaries_4"  and tostring(custom_text_secondary[Menucustom_pages._data.custom_pages_page_sec_4_val])  		--Page 4
or string_id == "bm_custom_page_secondaries_5"  and tostring(custom_text_secondary[Menucustom_pages._data.custom_pages_page_sec_5_val])  		--Page 5
or string_id == "bm_custom_page_secondaries_6"  and tostring(custom_text_secondary[Menucustom_pages._data.custom_pages_page_sec_6_val]) 		--Page 6
or string_id == "bm_custom_page_secondaries_7"  and tostring(custom_text_secondary[Menucustom_pages._data.custom_pages_page_sec_7_val])  		--Page 7
or string_id == "bm_custom_page_secondaries_8"  and tostring(custom_text_secondary[Menucustom_pages._data.custom_pages_page_sec_8_val])  		--Page 8
or string_id == "bm_custom_page_secondaries_9"  and tostring(custom_text_secondary[Menucustom_pages._data.custom_pages_page_sec_9_val])  		--Page 9
or string_id == "bm_custom_page_secondaries_10" and tostring(custom_text_secondary[Menucustom_pages._data.custom_pages_page_sec_10_val]) 		--Page 10

or string_id == "menu_custom_pages" and "Inventory page names" --Inventory page names
or string_id == "menu_custom_pages_desc" and "Customize the names of the pages in the Inventory" --Inventory page names


or string_id == "primary_fake_button" and "Primaries" 
or string_id == "primary_fake_button_desc" and "" 

or string_id == "secondary_fake_button" and "Secondaries" 
or string_id == "secondary_fake_button_desc" and "" 

or string_id == "custom_pages_page_1"       and "Page 1"
or string_id == "custom_pages_page_1_desc"  and "Page 1 Name"

or string_id == "custom_pages_page_2"       and "Page 2"
or string_id == "custom_pages_page_2_desc"  and "Page 2 Name"

or string_id == "custom_pages_page_3"       and "Page 3"
or string_id == "custom_pages_page_3_desc"  and "Page 3 Name" 

or string_id == "custom_pages_page_4"       and "Page 4"
or string_id == "custom_pages_page_4_desc"  and "Page 4 Name"

or string_id == "custom_pages_page_5"       and "Page 5"
or string_id == "custom_pages_page_5_desc"  and "Page 5 Name"

or string_id == "custom_pages_page_6"       and "Page 6"
or string_id == "custom_pages_page_6_desc"  and "Page 6 Name"

or string_id == "custom_pages_page_7"       and "Page 7"
or string_id == "custom_pages_page_7_desc"  and "Page 7 Name"

or string_id == "custom_pages_page_8"       and "Page 8"
or string_id == "custom_pages_page_8_desc"  and "Page 8 Name"

or string_id == "custom_pages_page_9"       and "Page 9"
or string_id == "custom_pages_page_9_desc"  and "Page 9 Name"

or string_id == "custom_pages_page_10"      and "Page 10"
or string_id == "custom_pages_page_10_desc" and "Page 10 Name"

or string_id == "custom_pages_page_sec_1"       and "Page 1"
or string_id == "custom_pages_page_sec_1_desc"  and "Page 1 Name"

or string_id == "custom_pages_page_sec_2"       and "Page 2"
or string_id == "custom_pages_page_sec_2_desc"  and "Page 2 Name"

or string_id == "custom_pages_page_sec_3"       and "Page 3"
or string_id == "custom_pages_page_sec_3_desc"  and "Page 3 Name" 

or string_id == "custom_pages_page_sec_4"       and "Page 4"
or string_id == "custom_pages_page_sec_4_desc"  and "Page 4 Name"

or string_id == "custom_pages_page_sec_5"       and "Page 5"
or string_id == "custom_pages_page_sec_5_desc"  and "Page 5 Name"

or string_id == "custom_pages_page_sec_6"       and "Page 6"
or string_id == "custom_pages_page_sec_6_desc"  and "Page 6 Name"

or string_id == "custom_pages_page_sec_7"       and "Page 7"
or string_id == "custom_pages_page_sec_7_desc"  and "Page 7 Name"

or string_id == "custom_pages_page_sec_8"       and "Page 8"
or string_id == "custom_pages_page_sec_8_desc"  and "Page 8 Name"

or string_id == "custom_pages_page_sec_9"       and "Page 9"
or string_id == "custom_pages_page_sec_9_desc"  and "Page 9 Name"

or string_id == "custom_pages_page_sec_10"      and "Page 10"
or string_id == "custom_pages_page_sec_10_desc" and "Page 10 Name"

or string_id == "cp_ARs"           and "Assault Rifles"
or string_id == "cp_Akimbos"       and "Akimbo"
or string_id == "cp_Shotguns"      and "Shotguns"
or string_id == "cp_LMGs"          and "LMGs"
or string_id == "cp_Specials"      and "Specials"
or string_id == "cp_Snipers"       and "Sniper Rifles"
or string_id == "cp_Bows"          and "Bows"
or string_id == "cp_custom_text_1" and "Grenade launchers"
or string_id == "cp_custom_text_2" and "Utility"
or string_id == "cp_custom_text_3" and "Name 3"
or string_id == "cp_custom_text_4" and "Name 4"

or string_id == "cp_Pistols"           	and "Pistols"
or string_id == "cp_SMGs"       		and "SMGs"
or string_id == "cp_Utility"       		and "Utility"
or string_id == "cp_Grenade_launchers" and "Grenade launchers"
or string_id == "cp_Crossbows"          and "Crossbows"
or string_id == "cp_custom_text_sec_2" and "2nd Name 2"
or string_id == "cp_custom_text_sec_3" and "2nd Name 3"
or string_id == "cp_custom_text_sec_4" and "2nd Name 4"

or original_text(self, string_id, ...)
end