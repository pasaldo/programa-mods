if RequiredScript == "lib/managers/menu/menunodegui" then
	function MenuNodeMainGui:_add_version_string() end
elseif RequiredScript == "lib/managers/menu/newsfeedgui" then
	function NewsFeedGui:make_news_request()
		local status = self._file_read_co and coroutine.status(self._file_read_co)
		if status == "running" or status == "suspended" then
			return
		end

		self._file_read_co = coroutine.create(function()
			local crashlog_path = Application:nice_path(Application:windows_user_folder() .. "/crashlog.txt")
			local file = io.open(crashlog_path, "r")
			if not file then
				self:news_result(false)
				return
			end

			local crashes = {}
			local crash_map = {}
			local t = os.clock()

			while true do
				local line = file:read("*l")
				if not line then
					break
				end

				local reason = line:match("Application has crashed: (.+)")
				if reason then
					line = file:read("*l") or ""
					if line ~= "" then
						reason = reason .. ": " .. line:gsub(".-:[0-9]+: ", "")
					end
					if not crash_map[reason] then
						crash_map[reason] = true
						table.insert(crashes, reason)
					end
				end

				if os.clock() - t > 0.01 then
					coroutine.yield()
					t = os.clock()
				end
			end

			file:close()

			self:news_result(true, crashes)
		end)

		Hooks:PostHook(self, "update", "crash_announcements_file_read_co", function(self)
			if not self._file_read_co or not coroutine.resume(self._file_read_co) then
				Hooks:RemovePostHook("crash_announcements_file_read_co")
			end
		end)
	end

	function NewsFeedGui:news_result(success, data)
		self._file_read_co = nil

		if not alive(self._panel) or not success then
			return
		end

		table.shuffle(data)

		self._titles = data
		self._links = table.collect(self._titles, function(t)
			return "https://www.google.com/search?q=" .. t:gsub("%+", "%%2B"):gsub(" ", "+")
		end)
		self._news = {
			i = 0
		}
		self._next = true

		self._panel:child("title_announcement"):set_visible(#self._titles > 0)
	end
end
