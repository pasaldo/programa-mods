# Smart Cover Peeking

Makes you peek over cover when you ADS in front of obstacles while crouched
