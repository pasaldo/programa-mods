# pd2-grenade-indicator
Displays warning markers for thrown grenades