local EHI = EHI
EHI:AddXPBreakdown({
    objective =
    {
        escape = 10000
    },
    no_total_xp = true
})
EHI:ShowLootCounter({ max = 4 })