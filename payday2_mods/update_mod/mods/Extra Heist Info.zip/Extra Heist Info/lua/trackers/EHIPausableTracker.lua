---@class EHIPausableTracker : EHITracker
---@field super EHITracker
EHIPausableTracker = class(EHITracker)
EHIPausableTracker._paused_color = EHI:GetColorFromOption("tracker_waypoint", "pause")
function EHIPausableTracker:init(panel, params, ...)
    EHIPausableTracker.super.init(self, panel, params, ...)
    self._update = not params.paused
    self:_set_pause(not self._update)
end

---@param pause boolean
function EHIPausableTracker:SetPause(pause)
    self:_set_pause(pause)
    if pause then
        self:RemoveTrackerFromUpdate()
    else
        self:AddTrackerToUpdate()
    end
end

function EHIPausableTracker:_set_pause(pause)
    self._paused = pause
    self:SetTextColor()
end

function EHIPausableTracker:SetTextColor(color)
    self._text:set_color(self._paused and self._paused_color or (color or self._text_color))
end