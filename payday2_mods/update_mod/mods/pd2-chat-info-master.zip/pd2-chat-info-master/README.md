# pd2-chat-info
BLT mod for displaying who is currently typing in chat